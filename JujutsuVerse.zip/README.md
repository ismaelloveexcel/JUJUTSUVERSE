# JUJUTSUVERSE
Real-time Jujutsu Kaisen 1v1 battles!

## Features
- Real-time WS battles
- Character select
- DB persistence/leaderboard
- UI animations
- Auth/sounds/PWA

## Start
npm i
Set SESSION_SECRET, Neon DB URL
npm run db:push
npm run dev

## Deploy Replit
Import from GitHub, run ‘npm run build’, start.
MIT.
